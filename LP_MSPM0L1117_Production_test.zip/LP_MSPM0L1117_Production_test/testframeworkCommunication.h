/*
 * communication.h
 *
 *  Created on: Dec 21, 2012
 *      Author: a0406309
 */

#ifndef TESTFRAMEWORKCOMMUNICATION_H_
#define TESTFRAMEWORKCOMMUNICATION_H_


#include "main.h"
#include "testframework.h"
#include "stdio.h"
#include "string.h"
#include "math.h"

#define BAUDRATE                (9600)


#define GPIO_UART_IOMUX_TX                                      (IOMUX_PINCM21)
#define GPIO_UART_IOMUX_TX_FUNCTION                 (IOMUX_PINCM21_PF_UART0_TX)
#define GPIO_UART_IOMUX_RX                                      (IOMUX_PINCM22)
#define GPIO_UART_IOMUX_RX_FUNCTION                 (IOMUX_PINCM22_PF_UART0_RX)

/* UART baud rate configuration */
#define UART_IBRD_32_MHZ_9600_BAUD                                       (0xD0)
#define UART_FBRD_32_MHZ_9600_BAUD                                       (0x15)

/* Definitions for UART_INST */
#define UART_INST                                                       (UART0)
#define UART_INST_IRQHandler                                   UART0_IRQHandler
#define UART_INST_INT_IRQN                                     (UART0_INT_IRQn)

void uartInit(void);
void uartSend(char * buf, unsigned char len);
void sendText(void);
/* clang-format on */
void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_UART_init(void);
void SYSCFG_DL_GPIO_init(void);
void uartReceive(char data);

#endif /* TESTFRAMEWORKCOMMUNICATION_H_ */
