/*
 * test_buttons.h
 *
 *  Created on: Oct 24, 2014
 *      Author: a0221162
 */

#ifndef TEST_BUTTONS_H_
#define TEST_BUTTONS_H_

#define LEFT_SWITCH_PRESSED (DL_GPIO_readPins(GPIO_SW1_PORT, GPIO_SW1_PIN))
#define RIGHT_SWITCH_PRESSED (!DL_GPIO_readPins(GPIO_SW2_PORT, GPIO_SW2_PIN))

char test_setup_buttonLeftPress(void);
char test_buttonLeftPress(void);

char test_setup_buttonLeftRelease(void);
char test_buttonLeftRelease(void);

char test_setup_buttonRightPress(void);
char test_buttonRightPress(void);

char test_setup_buttonRightRelease(void);
char test_buttonRightRelease(void);

#endif /* TEST_BUTTONS_H_ */
