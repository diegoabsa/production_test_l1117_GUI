/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/* CCS Version:  Version: 12.8.1.00005
   Compiler version : TI Clang v3.2.2.LTS
   SDK version: 2.02.00.06_internal
   10/01/2024  */

#include <main.h>
#include "testFramework.h"

int main(void)
{
    uint8_t lol = 8;
    // workaround for first power up need wait some for clock stable
    delay_cycles(900000);
    delay_cycles(900000);
    delay_cycles(900000);
    delay_cycles(900000);
    int i=0, k;
    SYSCFG_DL_init();

    unsigned char numTests = numberOfTestcases;
    char result;
    testFramework_Init();

    while(test.newStringReceived == FALSE); // Waits for the #START Message from the GUI before it starts the test

#define WAITTIMEAFTERTX 400000
    for(i = 0; i < numTests; /***/ ){

        // Setup Function
        //timeout
        if(testcases[i].timeoutms >= 1000){
            sprintf(test.txString,"#SET TIMEOUT 0%ds",(unsigned int)((testcases[i].timeoutms)/1000));
            sendText(); // fail log or instruction
            for (k = WAITTIMEAFTERTX; k > 0; k--);        // Delay
        }

        result = testcases[i].setup();
        sendText(); // fail log or instruction
        for (k = WAITTIMEAFTERTX; k > 0; k--);        // Delay

        // Actual Test only if setup succeeded
        if(result == PASS){
            result = testcases[i].test();
            sendText(); // test result
            for (k = WAITTIMEAFTERTX; k > 0; k--);        // Delay
        }

        // check test result
        if(result == PASS){
            i++;
            test.repeat = 0;
        }else{ /*fail*/
            if(testcases[i].repeat > test.repeat){
                test.repeat++;
                // one more time!
            }else if (testcases[i].continueOnFail){
                i++;
                test.repeat = 0;
            }else{
                test.overallTestResult = FAIL;
                test.repeat = 0;
                break;
            }
        }
        sprintf(test.txString,"!"); // Clear operator window
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
    }

    // sum up!
    if(test.overallTestResult == PASS){
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
        sprintf(test.txString,"#END(PASS)");
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
        sprintf(test.txString,"!Target Test PASS");
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
    }else{
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
        sprintf(test.txString,"#END(FAIL)");
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
        sprintf(test.txString,"!Target Test FAIL - This board is bad!");
        sendText();
        for (k = WAITTIMEAFTERTX; k > 0; k--);  // give PC some time...
    }
    while(1);
}


