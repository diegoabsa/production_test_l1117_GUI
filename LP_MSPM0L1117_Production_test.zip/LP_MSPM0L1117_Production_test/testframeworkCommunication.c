
#include "testframeworkCommunication.h"
//#include <ti/driverlib/dl_uart.c>
extern s_test test;
/**
* \brief uartReceive
*  adds bytes to the rx buffer
*
* @return void
*/
static char rxInProgress = FALSE;
char pieceOfString[MAX_STR_LENGTH] = "";           // Holds the new addition to the string
 char charCnt = 0;

void uartReceive(char data){

            	if( !rxInProgress){
            		if (data != '\n')
            		{
            			rxInProgress = TRUE;
            			pieceOfString[0] = data;
            			charCnt = 1;
            		}
            	}else{ // in progress
            		if(data == '\n'){
            			rxInProgress = FALSE;
            			if (test.newStringReceived == FALSE){ // don't mess with the string while main processes it.
            				strncpy(test.rxString,pieceOfString,charCnt);
            				test.newStringReceived = TRUE;
            				charCnt = 0;
            			}

            		}else{
            			if (charCnt >= MAX_STR_LENGTH){
            				rxInProgress = FALSE;
            			}else{
            				pieceOfString[charCnt++] = data;
            				//charCnt++;
            			}
            		}
            	}
}


void UART_INST_IRQHandler(void)
{
    char data = 0;
    switch (DL_UART_Main_getPendingInterrupt(UART_INST)) {
        case DL_UART_MAIN_IIDX_RX:
            data = DL_UART_Main_receiveData(UART_INST);
            uartReceive(data);
//              DL_UART_Main_transmitData(UART0, data);
        default:
            break;
    }
}

void SYSCFG_DL_init(void)
{
    SYSCFG_DL_initPower();
    SYSCFG_DL_GPIO_init();
    SYSCFG_DL_UART_init();
}

void SYSCFG_DL_initPower(void)
{
    DL_GPIO_reset(GPIOA);
    DL_GPIO_reset(GPIOB);
    DL_UART_Main_reset(UART_INST);

    DL_GPIO_enablePower(GPIOA);
    DL_GPIO_enablePower(GPIOB);
    DL_UART_Main_enablePower(UART_INST);

    delay_cycles(POWER_STARTUP_DELAY);
}

void SYSCFG_DL_GPIO_init(void)
{
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_UART_IOMUX_TX, GPIO_UART_IOMUX_TX_FUNCTION);
    DL_GPIO_initPeripheralInputFunction(
        GPIO_UART_IOMUX_RX, GPIO_UART_IOMUX_RX_FUNCTION);
}

static const DL_UART_Main_ClockConfig gUARTClockConfig = {
    .clockSel    = DL_UART_MAIN_CLOCK_BUSCLK,
    .divideRatio = DL_UART_MAIN_CLOCK_DIVIDE_RATIO_1};

static const DL_UART_Main_Config gUARTConfig = {
    .mode        = DL_UART_MAIN_MODE_NORMAL,
    .direction   = DL_UART_MAIN_DIRECTION_TX_RX,
    .flowControl = DL_UART_MAIN_FLOW_CONTROL_NONE,
    .parity      = DL_UART_MAIN_PARITY_NONE,
    .wordLength  = DL_UART_MAIN_WORD_LENGTH_8_BITS,
    .stopBits    = DL_UART_MAIN_STOP_BITS_ONE};

void SYSCFG_DL_UART_init(void)
{
    /* UART clock configuration to use BUSCLK at 8MHz */
    DL_UART_Main_setClockConfig(
            UART_INST, (DL_UART_Main_ClockConfig *) &gUARTClockConfig);

    /* UART configuration to operate in normal mode */
    DL_UART_Main_init(UART_INST, (DL_UART_Main_Config *) &gUARTConfig);

    /* Set UART baud rate divisors for 9600 baud, with UART clock of 8MHz,
     * and 16x oversampling rate */
    DL_UART_setOversampling(UART_INST, DL_UART_OVERSAMPLING_RATE_16X);
    DL_UART_setBaudRateDivisor(
            UART_INST, UART_IBRD_32_MHZ_9600_BAUD, UART_FBRD_32_MHZ_9600_BAUD);

    /* Configure RX interrupt to trigger when there is a new entry */
    DL_UART_Main_enableInterrupt(UART_INST, DL_UART_MAIN_INTERRUPT_RX);

    DL_UART_Main_enable(UART_INST);
    NVIC_ClearPendingIRQ(UART_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_INST_INT_IRQN);
}

/**
* \brief uartSend
*
* Send out message string
*
* @param char * buf			String of characters to send
* @param unsigned char len	Number of characters to send
*
* @return void
*/
void sendText(){
    unsigned char i = 0;

    while (i < MAX_STR_LENGTH){
        DL_UART_Main_transmitData(UART_INST, test.txString[i]);

        test.txString[i] = '\n';
        i++;
        // wait until UART ready
        while (DL_UART_isBusy(UART_INST));
    }
}
