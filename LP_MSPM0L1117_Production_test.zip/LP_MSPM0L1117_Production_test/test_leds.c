/*  test_leds.c
 *
 *  Created on: Oct 24, 2014
 *      Author: a0221162
 */

#include "main.h"
#include "testFrameWork.h"
#include "stdio.h"
#include "string.h"
#include "test_buttons.h"

char test_setup_led1(void){

    DL_GPIO_initDigitalOutput(GPIO_LED1_IOMUX);

    DL_GPIO_clearPins(GPIO_LED1_PORT, GPIO_LED1_PIN);

	sprintf(test.txString,"!LED1 on? --> Press Yes (S1) or No (S2)");
	return PASS;
}

char test_led1(void){
	char result = FALSE;
	while (1){
		if(LEFT_SWITCH_PRESSED){
			sprintf(test.txString,"@LED1 on (PASS)");
			result = PASS;
			break;
		}else if(RIGHT_SWITCH_PRESSED){
			sprintf(test.txString,"@LED1 not functional (FAIL)");
			result = FAIL;
			break;
		}
		if(test.timeout){
			sprintf(test.txString,"@LED1 test timed out (FAIL)");
			result = FAIL;
			break;
		}
	}
	DL_GPIO_setPins(GPIO_LED1_PORT, GPIO_LED1_PIN);
	return result;
}

char test_setup_led2R(void){

    DL_GPIO_initDigitalOutput(GPIO_LED2_R_IOMUX);
    DL_GPIO_enableOutput(GPIO_LED2_R_PORT, GPIO_LED2_R_PIN);
    DL_GPIO_setPins(GPIO_LED2_R_PORT, GPIO_LED2_R_PIN);

	sprintf(test.txString,"!RED LED2 on? --> Press Yes (S1) or No (S2)");
	return PASS;
}

char test_led2R(void){
	char result = FALSE;
	while (1){
		if(LEFT_SWITCH_PRESSED){
			sprintf(test.txString,"@RED LED2 on (PASS)");
			result = PASS;
			break;
		}else if(RIGHT_SWITCH_PRESSED){
			sprintf(test.txString,"@RED LED2 not functional (FAIL)");
			result = FAIL;
			break;
		}
		if(test.timeout){
			sprintf(test.txString,"@RED LED2 test timed out (FAIL)");
			result = FAIL;
			break;
		}
	}
    DL_GPIO_clearPins(GPIO_LED2_R_PORT, GPIO_LED2_R_PIN);
	return result;
}

char test_setup_led2G(void){
    DL_GPIO_setPins(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);
	sprintf(test.txString,"!GREEN LED2 on? --> Press Yes (S1) or No (S2)");
	return PASS;
}

char test_led2G(void){
	char result = FALSE;
	while (1){
		if(LEFT_SWITCH_PRESSED){
			sprintf(test.txString,"@GREEN LED2 on (PASS)");
			result = PASS;
			break;
		}else if(RIGHT_SWITCH_PRESSED){
			sprintf(test.txString,"@GREEN LED2 not functional (FAIL)");
			result = FAIL;
			break;
		}
		if(test.timeout){
			sprintf(test.txString,"@GREEN LED2 test timed out (FAIL)");
			result = FAIL;
			break;
		}
	}
    DL_GPIO_clearPins(GPIO_LED2_G_PORT, GPIO_LED2_G_PIN);
	return result;
}

char test_setup_led2B(void){
    DL_GPIO_initDigitalOutput(GPIO_LED2_B_IOMUX);
    DL_GPIO_enableOutput(GPIO_LED2_B_PORT, GPIO_LED2_B_PIN);
    DL_GPIO_setPins(GPIO_LED2_B_PORT, GPIO_LED2_B_PIN);

	sprintf(test.txString,"!BLUE LED2 on? --> Press Yes (S1) or No (S2)");
	return PASS;
}

char test_led2B(void){
	char result = FALSE;
	while (1){
		if(LEFT_SWITCH_PRESSED){
			sprintf(test.txString,"@BLUE LED2 on (PASS)");
			result = PASS;
			break;
		}else if(RIGHT_SWITCH_PRESSED){
			sprintf(test.txString,"@BLUE LED2 not functional (FAIL)");
			result = FAIL;
			break;
		}
		if(test.timeout){
			sprintf(test.txString,"@BLUE LED2 test timed out (FAIL)");
			result = FAIL;
			break;
		}
	}
    DL_GPIO_clearPins(GPIO_LED2_B_PORT, GPIO_LED2_B_PIN);
	return result;
}
