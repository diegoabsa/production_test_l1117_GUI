/*
 * testFrameWork.c
 *
 *  Created on: Dec 21, 2012
 *      Author: a0406309
 */
#include "main.h"
#include "testFramework.h"
#include "stdio.h"
#include "string.h"
#include "test_dieRecord.h"
#include "test_buttons.h"
#include "test_leds.h"

s_test test = {
	PASS,
	FALSE,
	0,
	FALSE,
	"",
	""
};

void testFramework_Init(void){
	test.overallTestResult = PASS;
	test.timeout = FALSE;
	test.repeat	= 0;
	test.newStringReceived = FALSE;
}

const s_testcase testcases[] = {
	 /* setup function			*/	/* test function	  */	/* timout in ms */	/* #of retries*/	/* continue on fail?*/
	{&test_noSetup,					&test_waitForGuiToStart,	0,					2,					FALSE},
	{&test_noSetup,					&test_testFramework,		0,					0,					FALSE},
	{&test_noSetup,					&test_dieRecord,			0,					0,					FALSE},
    {&test_setup_buttonLeftPress,   &test_buttonLeftPress,      30000,              0,                  FALSE},
    {&test_setup_buttonLeftRelease, &test_buttonLeftRelease,    30000,              0,                  FALSE},
    {&test_setup_buttonRightPress,  &test_buttonRightPress,     30000,              0,                  FALSE},
    {&test_setup_buttonRightRelease,&test_buttonRightRelease,   30000,              0,                  FALSE},
    {&test_setup_led1,              &test_led1,                 30000,              1,                  FALSE},
    {&test_setup_led2R,             &test_led2R,                30000,              1,                  FALSE},
    {&test_setup_led2G,             &test_led2G,                30000,              1,                  FALSE},
    {&test_setup_led2B,             &test_led2B,                30000,              1,                  FALSE},

};

const unsigned int numberOfTestcases = (sizeof(testcases) / sizeof(s_testcase));

char test_noSetup(void){
	return PASS;
}

char test_waitForGuiToStart(void){
	// Wait for GUI to start test
	while (test.newStringReceived == FALSE);

	if(strcmp(test.rxString,"#START")==0){
		test.newStringReceived = FALSE;
		return PASS;
	}else{
		test.newStringReceived = FALSE;
		return FAIL;
	}
}

char test_testFramework(void){
	sprintf(test.txString,"@LP-MSPM0L1117 Production Test r%s, b%s/%s",FWVERSION,__DATE__,__TIME__);
	return PASS;
}

