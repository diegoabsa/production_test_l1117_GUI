/*
 * test_leds.h
 *
 *  Created on: Oct 24, 2014
 *      Author: a0221162
 */

#ifndef TEST_LEDS_H_
#define TEST_LEDS_H_

char test_setup_led1(void);
char test_led1(void);
char test_setup_led2R(void);
char test_led2R(void);
char test_setup_led2G(void);
char test_led2G(void);
char test_setup_led2B(void);
char test_led2B(void);

#endif /* TEST_LEDS_H_ */
